width : max-content & min-content;

is javascript single-threaded or multi-threaded?
ans : single-threaded