// let i = 4;

// console.log("start");

// const value = setInterval(() => {
//   i -= 1;

//   console.log(i);

//   if (i == 0) {
//     console.log("ended");
//     clearInterval(value);
//   }
// }, 1000);

// -----------------------------------------------------

// we can change value while using array and object in const variable, but can't change in string, number and other etc.

// const arr = [1,2,3]
// arr[0] = 10

// console.log(arr)

// const obj = {
//     name : "Daksh"
// }

// obj.name = 'Govind'
// console.log(obj)

// const str = "Daksh"
// str = 'Govind'
// console.log(str)

// -------------------------------------------------------

// first method
// i want to console 40

// const [,,,a] = [10,20,30,40,50];
// console.log(a)


// const {3:a} = [10,20,30,40,50]
// console.log(a)


// ------------------------------------------------------------

